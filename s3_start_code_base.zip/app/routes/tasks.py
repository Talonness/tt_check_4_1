# app/routes/tasks.py
from flask import Blueprint, request, jsonify, abort
from app.services.task_storage import load_tasks, save_tasks

tasks_bp = Blueprint('tasks', __name__, url_prefix='/api/tasks')

def get_next_id():
    """Get the next available task ID based on existing tasks.
    
    TEMPORARY: This helper function will be replaced when refactoring to use a database.
    In a database, we'll use auto-incrementing primary keys or UUIDs.
    """
    tasks = load_tasks()
    if not tasks:
        return 1
    return max(task['id'] for task in tasks) + 1

@tasks_bp.route('/reset', methods=['POST'])
def reset_tasks():
    """
    Development endpoint to reset tasks data.
    WARNING: Only use for testing/development!
    """
    # Save empty list to clear all tasks
    save_tasks([])
    return jsonify({"message": "Tasks reset successfully"}), 200

@tasks_bp.route('', methods=['POST'])
def add_task():
    """ Create a task or return a validation error.

       Valid Request
       Invalid:
        - Missing title
        - Empty title      
    """
    data = request.get_json() or {}
    title = data.get("title")
    if not data or "title" not in data or not data["title"] or data["title"].strip() == "":
        return jsonify({"error": "Title is required"}), 400
    
    # Load existing tasks and create new task
    tasks = load_tasks()
    task = {
        "id": get_next_id(),
        "title": title,
        "description": data.get("description", ""),
        "completed": False
    }
    tasks.append(task)
    save_tasks(tasks)
    return jsonify(task), 201

@tasks_bp.route('', methods=['GET'])
def list_tasks():
    """Return the list of all tasks. GET /api/tasks"""
    tasks = load_tasks()
    return jsonify(tasks), 200

# app/routes/tasks.py
@tasks_bp.route("/<int:task_id>", methods=["PUT"])
def complete_task(task_id):
    """
    US005 - tests/tasks/test_complete_task.py`
    """
    tasks = load_tasks()
    for task in tasks:
        if task["id"] == task_id:
            task["completed"] = True
            save_tasks(tasks)
            return jsonify(task), 200
    return jsonify({"error": "Task not found"}), 404

@tasks_bp.route("/<int:task_id>", methods=["DELETE"])
def delete_task(task_id):
    tasks = load_tasks()
    for task in tasks:
        if task["id"] == task_id:
            tasks.remove(task)
            save_tasks(tasks)
            return jsonify({"message": "Task deleted"}), 200
    return jsonify({"error": "Task not found"}), 404