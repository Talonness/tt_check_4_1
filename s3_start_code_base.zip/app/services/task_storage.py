# app/services/task_storage.py
import os
import json

DATA_FILE = os.path.join("app", "data", "tasks.json")

def load_tasks():
    """Load tasks from the JSON file or return an empty list on failure."""
    try:
        with open(DATA_FILE, "r") as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError, IOError):
        return []

def save_tasks(tasks):
    """Write the task list to the JSON file, ensuring directory exists."""
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    try:
        with open(DATA_FILE, "w") as file:
            json.dump(tasks, file, indent=2)
    except IOError as e:
        print(f"[Warning] Error saving tasks: {e}")