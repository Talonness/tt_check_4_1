import os
import json
import pytest
from app import create_app

    # 📍 Location of the persistent task file
DATA_FILE = os.path.join("app", "data", "tasks.json")

@pytest.fixture
def client():
    """
    Provides a Flask test client for simulating API requests.
    All test files can use this without repeating code.
    """
    app = create_app()
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client

@pytest.fixture(autouse=True)
def reset_tasks(client):
    """
    Ensures each test starts with a clean environment (test isolation).

    ✅ Supports:
    - File-based reset by emptying data/tasks.json
    - API-based reset if /api/tasks/reset is implemented

    🧪 Why this matters:
    - Without it, tests could pass/fail inconsistently due to leftover task data.
    - Ensures reliable and reproducible test results.
    """
    try:
        response = client.post("/api/tasks/reset")
        assert response.status_code == 200
    except Exception:
        # 2️⃣ If API reset fails, clear the file manually
        os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
        with open(DATA_FILE, "w") as f:
            json.dump([], f)

    yield  # Execute the test

    try:
        client.post("/api/tasks/reset")
    except Exception:
        with open(DATA_FILE, "w") as f:
            json.dump([], f)