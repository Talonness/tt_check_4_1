# ISSUES TEMPLATES

## Templates developed for CSC.256
- CSC 256 Bug Report
- Design Flaws
- Documentation Updates
- Features Requirment
- Feedback Suggestions
- Meeting Agenda
- Meeting Minutes
- Peer Code Reviews
- Progress Update
- Resource Requirement
- Task Assignment
- Sprint Epic
- Sprint Sub-Issue
